<?php

define("HOST","localhost");
define("USER","vinidevt_job_user");
define("PASSWORD","J147852369#");
define("DATABASE","vinidevt_job");

?>